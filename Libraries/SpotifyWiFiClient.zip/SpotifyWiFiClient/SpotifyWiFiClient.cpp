#include <Arduino.h>
#include <SpotifyWiFiClient.h>

SpotifyWiFiClient::SpotifyWiFiClient(String clientId, String clientSecret, String refreshToken) : 
    SpotifyAPIFunctionality(clientId, clientSecret, refreshToken) {};

// Oauth Methods
void SpotifyWiFiClient::getOAuthToken() {
    SSLClient.stop();
    if(SSLClient.connectSSL(spotifyAccounts.c_str(), CONNECTION_PORT)) {
        SSLClient.println(POST + " /api/token " + HTTP_VERSION);
        SSLClient.println(HOST + spotifyAPI);
        SSLClient.println(AUTHORIZATION + "Basic " + (char *) base64);
        SSLClient.println(CONTENT_TYPE + "application/x-www-form-urlencoded");
        SSLClient.println(CONTENT_LENGTH + postData.length());
        SSLClient.println(CONNECTION_CLOSE);
        SSLClient.println();
        SSLClient.println(postData);
    }
}

// Album Art Methods
void SpotifyWiFiClient::getAlbumArtURL() {
    SSLClient.stop();
    if(SSLClient.connectSSL(spotifyAPI.c_str(), CONNECTION_PORT)) {
        SSLClient.println(GET + " /v1/me/player/currently-playing " + HTTP_VERSION);
        SSLClient.println(HOST + spotifyAPI);
        SSLClient.println(AUTHORIZATION + "Bearer " + oauthToken);
        SSLClient.println(CONTENT_TYPE + "application/json");
        SSLClient.println(CONNECTION_CLOSE);
        SSLClient.println();
    }
}

void SpotifyWiFiClient::getAlbumArt() {
    SSLClient.stop();
    const int beginningIndex = albumArtURL.indexOf("//") + 2;
    String imageApi = albumArtURL.substring(beginningIndex, albumArtURL.indexOf("/", beginningIndex));
    String imageExtension = albumArtURL.substring(albumArtURL.indexOf("/", beginningIndex));

    if(SSLClient.connectSSL(imageApi.c_str(), CONNECTION_PORT)) {
        SSLClient.println(GET + imageExtension + " " + HTTP_VERSION);
        SSLClient.println(HOST + imageApi);
        SSLClient.println(AUTHORIZATION + "Bearer " + oauthToken);
        SSLClient.println(CONNECTION_CLOSE);
        SSLClient.println();
    }
}

// Checking methods
bool SpotifyWiFiClient::checkHTTPStatus() {
    char status[32] = {0};
    SSLClient.readBytesUntil('\r', status, sizeof(status));
    if (strcmp(status, "HTTP/1.1 200 OK") != 0) {
        Serial.print("Unexpected response: ");
        Serial.println(status);
        SSLClient.stop();
        return false;
    }
    return true;
}

bool SpotifyWiFiClient::skipHTTPHeaders() {
    char endOfHeaders[] = "\r\n\r\n";
    if (!SSLClient.find(endOfHeaders)) {
        Serial.println("Invalid response");
        SSLClient.stop();
        return false;
    }
}


void SpotifyWiFiClient::nextClient() {
    currentClient = static_cast<ClientType>((currentClient) + 1 % ClientType::NUM_CLIENTS);
}
