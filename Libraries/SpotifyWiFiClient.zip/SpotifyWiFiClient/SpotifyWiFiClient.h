#ifndef SPOTIFY_WIFI_CLIENT
#define SPOTIFY_WIFI_CLIENT

#include <Arduino.h>
#include <WiFiNINA.h>
#include<SpotifyAPIFunctionality.h>

class SpotifyWiFiClient : public SpotifyAPIFunctionality {
    public:
        SpotifyWiFiClient(String, String, String);

        void getOAuthToken();
        void getAlbumArtURL();
        void getAlbumArt();

        bool checkHTTPStatus();
        bool skipHTTPHeaders();

        void nextClient();

        WiFiSSLClient SSLClient;
        enum ClientType {OAUTH, ALBUM_URL, ALBUM_ART, NUM_CLIENTS};
        ClientType currentClient = ClientType::OAUTH;

        String oauthToken;
        long oauthExpiryTime = 0;

        long nextAlbumArtRetrievalTime = 0;
        long nextDisplayUpdate = 0;
        String albumArtURL;

        // Wifi Constants
        const uint16_t CONNECTION_PORT = 443;
        String GET = "GET";
        String POST = "POST";
        String HOST = "Host: ";
        String AUTHORIZATION = "Authorization: ";
        String HTTP_VERSION = "HTTP/1.1";
        String CONTENT_TYPE = "Content-Type: ";
        String CONTENT_LENGTH = "Content-Length: ";
        String CONNECTION_CLOSE = "Connection: close";
};


#endif