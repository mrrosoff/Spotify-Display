#include <Arduino.h>
#include <SpotifyAPIFunctionality.h>
#include "base64.hpp"

SpotifyAPIFunctionality::SpotifyAPIFunctionality(String clientId, String clientSecret, String refreshToken) : 
    clientId(clientId), clientSecret(clientSecret), refreshToken(refreshToken), builtClientId(clientId + ":" + clientSecret),
    postData("grant_type=refresh_token&refresh_token=" + refreshToken) {
        encode_base64((unsigned char *) builtClientData.c_str(), strlen(builtClientData.c_str()), base64);
    };