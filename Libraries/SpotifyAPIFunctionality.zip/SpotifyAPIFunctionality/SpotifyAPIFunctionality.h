#ifndef SPOTIFY_API_FUNCTIONALITY
#define SPOTIFY_API_FUNCTIONALITY

#include <Arduino.h>

class SpotifyAPIFunctionality {

    public:
        SpotifyAPIFunctionality(String , String , String );

        // Spotify Credientials
        String clientId;
        String builtClientId;
        String clientSecret;
        String refreshToken;
        String builtClientData;
        unsigned char base64[128] = {0};
        String postData;
        String spotifyAccounts = "accounts.spotify.com";
        String spotifyAPI = "api.spotify.com";
};

#endif