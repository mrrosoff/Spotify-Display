#ifndef WIFIUTILITIES
#define WIFIUTILITIES

#include <Arduino.h>

class WiFiUtilities {
    public:
        WiFiUtilities(String, String);

        void checkWiFiModule();
        void connectToWiFi();

        String ssid, password;
};

#endif